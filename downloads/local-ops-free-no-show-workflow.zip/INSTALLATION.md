# Installation Guide

## 1. Use Customer-owned Accounts

The end customer should own n8n, email, messaging, CRM, calendar, and spreadsheet accounts. Do not place multiple unrelated customers in one credential or data store.

## 2. Import

In n8n, choose **Import from File** and select one workflow JSON file. Imported workflows are inactive by default.

## 3. Configure

- Replace all `YOUR_*` placeholder values.
- Create provider credentials in n8n rather than pasting secrets into Code nodes.
- Set the timezone to the customer's business timezone.
- Confirm sender authentication and reply handling.
- Connect the activity log destination.

## 4. Test

Use a test contact controlled by the operator. Send each fixture to the workflow's test webhook and verify:

- One event produces no more than one initial message.
- Opt-out or closed status prevents future messages.
- Failure alerts reach staff.
- Logs contain the event ID, timestamp, action, and result.
- Re-running the same event does not create a duplicate send.

The sample HTTP request includes an idempotency key. Confirm that the selected provider honors it. If not, add a customer-specific data store lookup before the send node.

## 5. Activate Gradually

Run staff-only tests first. Then activate for a small percentage or one location. Review executions daily during the first week.
