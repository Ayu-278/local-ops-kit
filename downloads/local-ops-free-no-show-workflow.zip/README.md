﻿# Free No-show Recovery Sample

This sample is one workflow from the Local Ops Automation Kit.

It is inactive by default. Use a customer-owned test account, replace every placeholder, and follow INSTALLATION.md before activation.

The full paid kit adds quote follow-up, review requests, fixtures, customization documentation, a launch checklist, and commercial license options.
